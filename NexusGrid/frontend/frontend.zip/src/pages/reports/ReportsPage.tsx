import { useState, useMemo } from 'react';
import { useQuery, keepPreviousData } from '@tanstack/react-query';
import {
  BarChart, Bar, PieChart, Pie, Cell, Legend, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart,
} from 'recharts';
import {
  RefreshCw, Building2, Layers, LayoutDashboard, BookOpen, Download,
  FileText, TrendingUp, AlertTriangle, Package, Monitor, Filter, X,
} from 'lucide-react';
import { reportsApi, layoutApi, labsApi, privilegesApi } from '@/lib/api';
import PageHeader from '@/components/common/PageHeader';
import ErrorState from '@/components/common/ErrorState';
import OversightSection from '@/pages/reports/OversightSection';
import { generatePdfReport } from '@/lib/pdfReport';
import { useTheme } from '@/hooks/useTheme';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';
import type { LayoutItem, Lab, ReportsData, ReportsDetailData } from '@/types';

const COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6', '#06b6d4', '#ec4899'];
const PIE_COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6', '#06b6d4'];

type ReportFilterParams = { building_id?: number; floor_id?: number; lab_id?: number };

function csvEscape(value: unknown): string {
  const raw = String(value ?? '').replace(/\r?\n/g, ' ').trim();
  if (raw.includes(',') || raw.includes('"')) {
    return `"${raw.replace(/"/g, '""')}"`;
  }
  return raw;
}

function buildCsvSection(title: string, headers: string[], rows: unknown[][]): string {
  const lines = [title, headers.join(',')];
  rows.forEach((row) => {
    lines.push(row.map(csvEscape).join(','));
  });
  lines.push('');
  return lines.join('\n');
}

function triggerDownload(blob: Blob, fileName: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// ─── Section wrapper with icon header ─────────────────────────────────────────
function ChartSection({ icon: Icon, title, subtitle, children, className }: {
  icon: React.ElementType;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`card overflow-hidden ${className ?? ''}`}>
      <div className="flex items-center gap-3 px-5 pt-5 pb-3">
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950/50">
          <Icon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-200">{title}</h3>
          {subtitle && <p className="text-xs text-slate-400 dark:text-slate-500">{subtitle}</p>}
        </div>
      </div>
      <div className="px-5 pb-5">{children}</div>
    </div>
  );
}

// ─── Filter select ────────────────────────────────────────────────────────────
function FilterSelect({
  label, icon: Icon, value, onChange, disabled, placeholder, options, dark,
}: {
  label: string;
  icon: React.ElementType;
  value: number | '';
  onChange: (v: number | '') => void;
  disabled?: boolean;
  placeholder: string;
  options: { id: number; name: string }[];
  dark: boolean;
}) {
  return (
    <div className="flex flex-col gap-1.5 min-w-[170px]">
      <label className={`text-xs font-medium flex items-center gap-1.5 ${dark ? 'text-slate-400' : 'text-slate-500'}`}>
        <Icon className="w-3.5 h-3.5" />
        {label}
      </label>
      <select
        value={value}
        onChange={e => onChange(e.target.value === '' ? '' : Number(e.target.value))}
        disabled={disabled}
        className={`text-sm rounded-lg border px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/40 transition
          ${dark
            ? 'bg-slate-800 border-slate-600 text-slate-200 disabled:text-slate-600'
            : 'bg-white border-slate-200 text-slate-700 disabled:text-slate-400'
          } disabled:cursor-not-allowed`}
      >
        <option value="">{placeholder}</option>
        {options.map(o => (
          <option key={o.id} value={o.id}>{o.name}</option>
        ))}
      </select>
    </div>
  );
}

// ─── Summary stat card ────────────────────────────────────────────────────────
function StatCard({ label, value, icon: Icon, color, subtext }: {
  label: string;
  value: number;
  icon: React.ElementType;
  color: string;
  subtext?: string;
}) {
  return (
    <div className="card p-4 flex items-center gap-4">
      <div className={`flex items-center justify-center w-11 h-11 rounded-xl ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div>
        <p className="text-2xl font-bold text-slate-900 dark:text-slate-100">{value}</p>
        <p className="text-xs text-slate-500 dark:text-slate-400">{label}</p>
        {subtext && <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">{subtext}</p>}
      </div>
    </div>
  );
}

export default function ReportsPage() {
  const { theme } = useTheme();
  const dark = theme === 'dark';
  const user = useAuthStore(s => s.user);
  const isNoRole = user?.role === 'No Roles';
  const isAdmin = user?.role === 'Administrator';
  const isRestricted = user?.role === 'Lab Incharge' || user?.role === 'Lab Assistant';

  if (isNoRole) {
    return (
      <div className="space-y-5 animate-fade-in">
        <PageHeader
          title="Reports & Analytics"
          description="Visual overview of faults, resources, and system status."
        />
        <div className={`flex flex-col items-center justify-center py-20 rounded-xl border
          ${dark
            ? 'bg-slate-900 border-slate-700 text-slate-400'
            : 'bg-white border-slate-200 text-slate-500'
          }`}>
          <LayoutDashboard className="w-10 h-10 mb-4 opacity-30" />
          <p className="text-base font-medium mb-1">No reports available</p>
          <p className="text-sm text-center max-w-xs">
            Your account has no role assigned. Contact an administrator to get access.
          </p>
        </div>
      </div>
    );
  }

  // ── Admin filter state ──────────────────────────────────────────────────
  const [selectedBuilding, setSelectedBuilding] = useState<number | ''>('');
  const [selectedFloor, setSelectedFloor] = useState<number | ''>('');
  const [selectedLab, setSelectedLab] = useState<number | ''>('');

  // ── Incharge/Assistant filter state ────────────────────────────────────
  const [selectedRestrictedLab, setSelectedRestrictedLab] = useState<number | ''>('');
  const [exportingCsv, setExportingCsv] = useState(false);
  const [exportingPdf, setExportingPdf] = useState(false);

  // ── Fetch this user's own active assignments (incharge / assistant) ─────
  const { data: myAssignments = [] } = useQuery({
    queryKey: ['my-assignments'],
    queryFn: () => privilegesApi.getAssignments().then(r => r.data as { id: number; lab: number; lab_name: string }[]),
    enabled: isRestricted,
    staleTime: 5 * 60 * 1000,
  });

  const myLabs = useMemo(() => {
    const seen = new Set<number>();
    return myAssignments.filter(a => {
      if (seen.has(a.lab)) return false;
      seen.add(a.lab);
      return true;
    });
  }, [myAssignments]);

  // ── Layout data for admin filter dropdowns ──────────────────────────────
  const { data: buildings = [] } = useQuery<LayoutItem[]>({
    queryKey: ['layout-buildings'],
    queryFn: () => layoutApi.getItems().then(r =>
      (r.data as LayoutItem[]).filter(i => i.item_type === 'building'),
    ),
    enabled: isAdmin,
    staleTime: 10 * 60 * 1000,
  });

  const { data: floors = [] } = useQuery<LayoutItem[]>({
    queryKey: ['layout-floors', selectedBuilding],
    queryFn: () => layoutApi.getItems({ parent_id: selectedBuilding as number }).then(r =>
      (r.data as LayoutItem[]).filter(i => i.item_type === 'floor'),
    ),
    enabled: isAdmin && !!selectedBuilding,
    staleTime: 10 * 60 * 1000,
  });

  const { data: allLabs = [] } = useQuery<Lab[]>({
    queryKey: ['labs'],
    queryFn: () => labsApi.list().then(r => r.data),
    enabled: isAdmin && !!selectedBuilding,
    staleTime: 10 * 60 * 1000,
  });

  const labsForFloor = useMemo((): Lab[] => {
    if (!selectedFloor) return [];
    return allLabs.filter(l => l.floor_id === selectedFloor);
  }, [allLabs, selectedFloor]);

  // ── Derive report query params ───────────────────────────────────────────
  const reportParams = useMemo<ReportFilterParams | undefined>(() => {
    if (isRestricted) {
      return selectedRestrictedLab ? { lab_id: selectedRestrictedLab as number } : undefined;
    }
    if (!isAdmin) return undefined;
    if (selectedLab) return { lab_id: selectedLab as number };
    if (selectedFloor) return { floor_id: selectedFloor as number };
    if (selectedBuilding) return { building_id: selectedBuilding as number };
    return undefined;
  }, [isAdmin, isRestricted, selectedBuilding, selectedFloor, selectedLab, selectedRestrictedLab]);

  // ── Scope label ─────────────────────────────────────────────────────────
  const scopeLabel = useMemo(() => {
    if (isRestricted) {
      if (selectedRestrictedLab) {
        const l = myLabs.find(l => l.lab === selectedRestrictedLab);
        return l ? l.lab_name : null;
      }
      return null;
    }
    if (!isAdmin) return null;
    const parts: string[] = [];
    if (selectedBuilding) {
      const b = buildings.find(b => b.id === selectedBuilding);
      if (b) parts.push(b.name);
    }
    if (selectedFloor) {
      const f = floors.find(f => f.id === selectedFloor);
      if (f) parts.push(f.name);
    }
    if (selectedLab) {
      const l = labsForFloor.find(l => l.id === selectedLab);
      if (l) parts.push(l.lab_name);
    }
    return parts.length ? parts.join(' › ') : null;
  }, [isAdmin, isRestricted, selectedBuilding, selectedFloor, selectedLab, selectedRestrictedLab, buildings, floors, labsForFloor, myLabs]);

  const gridStroke = dark ? '#334155' : '#e2e8f0';
  const tickFill = dark ? '#64748b' : '#94a3b8';
  const tooltipStyle = {
    fontSize: 12, borderRadius: 10,
    boxShadow: '0 8px 30px rgba(0,0,0,.12)',
    backgroundColor: dark ? '#1e293b' : '#ffffff',
    color: dark ? '#f1f5f9' : '#0f172a',
    border: `1px solid ${dark ? '#334155' : '#e2e8f0'}`,
    padding: '10px 14px',
  };
  const tooltipLabelStyle = { color: dark ? '#cbd5e1' : '#374151', fontWeight: 600, marginBottom: 4 };
  const tooltipItemStyle = { color: dark ? '#94a3b8' : '#475569' };
  const tooltipCursor = { fill: dark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.03)' };
  const tooltipProps = {
    contentStyle: tooltipStyle,
    labelStyle: tooltipLabelStyle,
    itemStyle: tooltipItemStyle,
    cursor: tooltipCursor,
  };
  const legendStyle = { fontSize: 11, color: dark ? '#94a3b8' : '#64748b' };

  const { data, isLoading, isError, refetch } = useQuery<ReportsData>({
    queryKey: ['reports', reportParams],
    queryFn: () => reportsApi.get(reportParams).then(r => r.data),
    staleTime: 5 * 60 * 1000,
    placeholderData: keepPreviousData,
  });

  if (isError) return <ErrorState message="Failed to load reports data." onRetry={refetch} />;

  const skeletonChart = (
    <div className={`h-52 rounded-xl animate-pulse ${dark ? 'bg-slate-700/50' : 'bg-slate-100'}`} />
  );

  const isFiltered = isRestricted
    ? !!selectedRestrictedLab
    : !!(selectedBuilding || selectedFloor || selectedLab);

  // Pivot fault_monthly into chart series
  const faultMonthly = data?.fault_monthly ?? [];
  const months = [...new Set(faultMonthly.map(x => x.month))];
  const types = [...new Set(faultMonthly.map(x => x.type))];
  const faultTrendData = months.map(m => {
    const row: Record<string, string | number> = { month: m };
    types.forEach(t => {
      row[t] = faultMonthly.find(x => x.month === m && x.type === t)?.count ?? 0;
    });
    return row;
  });

  const faultByStatusData = Object.entries(data?.fault_by_status ?? {}).map(([name, value]) => ({
    name: name.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
    value,
  }));

  const faultByTypeData = Object.entries(data?.fault_by_type ?? {}).map(([name, value]) => ({
    name, value,
  }));

  const resourceByStatusData = Object.entries(data?.resource_by_status ?? {}).map(([name, value]) => ({
    name, value,
  }));

  const systemByStatusData = Object.entries(data?.system_by_status ?? {}).map(([name, value]) => ({
    name: name === 'non-functional' ? 'Non-Functional' : name.charAt(0).toUpperCase() + name.slice(1),
    value,
  }));

  const resourceTrend = (data?.resource_monthly ?? []).map(x => ({
    month: x.month,
    count: x.count,
  }));

  const fileScope = scopeLabel
    ? scopeLabel.replace(/[^a-zA-Z0-9-_ ]/g, '').replace(/\s+/g, '_')
    : isRestricted
    ? 'assigned_labs'
    : 'all';

  // Summary numbers
  const totalFaults = Object.values(data?.fault_by_status ?? {}).reduce((a, b) => a + b, 0);
  const resolvedFaults = data?.fault_by_status?.['resolved'] ?? 0;
  const totalResources = Object.values(data?.resource_by_status ?? {}).reduce((a, b) => a + b, 0);
  const totalSystems = Object.values(data?.system_by_status ?? {}).reduce((a, b) => a + b, 0);

  const fetchExportData = async (): Promise<ReportsDetailData> => {
    const res = await reportsApi.details(reportParams);
    return res.data as ReportsDetailData;
  };

  const downloadDetailedCsv = async () => {
    setExportingCsv(true);
    try {
      const detail = await fetchExportData();
      const now = new Date();
      const generatedAt = detail.generated_at ? new Date(detail.generated_at).toLocaleString() : now.toLocaleString();
      const chunks: string[] = [
        `NexusGrid Detailed Report`,
        `Scope,${csvEscape(scopeLabel ?? (isRestricted ? 'Assigned Labs' : 'All'))}`,
        `Generated At,${csvEscape(generatedAt)}`,
        '',
      ];

      chunks.push(buildCsvSection(
        'Systems',
        ['ID', 'Host Name', 'Status', 'Building', 'Floor', 'Room', 'Lab', 'Updated At'],
        detail.systems.map(s => [s.id, s.host_name, s.status, s.building_name, s.floor_name, s.room_name, s.lab_name, s.updated_at]),
      ));

      chunks.push(buildCsvSection(
        'Faults',
        ['Fault ID', 'Reported At', 'Status', 'Type', 'Risk', 'System', 'Building', 'Floor', 'Room', 'Lab', 'Reported By', 'Description', 'Resolution Summary', 'Resolved At', 'Resolved By'],
        detail.faults.map(f => [
          f.fault_id, f.reported_at, f.status, f.fault_type, f.risk_factor, f.system_name,
          f.building_name, f.floor_name, f.room_name, f.lab_name, f.reported_by,
          f.description, f.resolution_summary, f.resolved_at, f.resolved_by,
        ]),
      ));

      chunks.push(buildCsvSection(
        'Resource Requests',
        ['Resource ID', 'Requested At', 'Status', 'Resource Name', 'System', 'Building', 'Floor', 'Room', 'Lab', 'Requested By', 'Description', 'Provision Summary', 'Provided At', 'Provided By'],
        detail.resources.map(r => [
          r.resource_id, r.requested_at, r.status, r.resource_name, r.system_name,
          r.building_name, r.floor_name, r.room_name, r.lab_name, r.requested_by,
          r.description, r.provision_summary, r.provided_at, r.provided_by,
        ]),
      ));

      const csv = chunks.join('\n');
      triggerDownload(new Blob([csv], { type: 'text/csv;charset=utf-8;' }), `nexusgrid_detailed_report_${fileScope}.csv`);
      toast.success('Detailed CSV downloaded.');
    } catch {
      toast.error('Failed to download CSV report.');
    } finally {
      setExportingCsv(false);
    }
  };

  const downloadDetailedPdf = async () => {
    setExportingPdf(true);
    try {
      const detail = await fetchExportData();
      generatePdfReport({
        title: 'Detailed Infrastructure Report',
        subtitle: `Scope: ${scopeLabel ?? (isRestricted ? 'Assigned Labs' : 'All')}`,
        meta: [`Data as of: ${detail.generated_at ? new Date(detail.generated_at).toLocaleString() : new Date().toLocaleString()}`],
        stats: [
          { label: 'Systems', value: String(detail.systems.length), color: 'violet' },
          { label: 'Faults', value: String(detail.faults.length), color: 'red' },
          { label: 'Resource Requests', value: String(detail.resources.length), color: 'blue' },
        ],
        tables: [
          {
            title: `Systems (${detail.systems.length})`,
            columns: [
              { header: 'ID', key: 'id', width: 35 },
              { header: 'Host Name', key: 'host' },
              { header: 'Status', key: 'status', width: 90, isStatus: true },
              { header: 'Building', key: 'building', width: 100 },
              { header: 'Room', key: 'room', width: 90 },
              { header: 'Lab', key: 'lab', width: 100 },
            ],
            rows: detail.systems.map((s) => ({
              id: s.id, host: s.host_name, status: s.status,
              building: s.building_name, room: s.room_name, lab: s.lab_name,
            })),
          },
          {
            title: `Faults (${detail.faults.length})`,
            columns: [
              { header: 'ID', key: 'id', width: 35 },
              { header: 'Reported', key: 'date', width: 62 },
              { header: 'Status', key: 'status', width: 78, isStatus: true },
              { header: 'Type', key: 'type', width: 70 },
              { header: 'Risk', key: 'risk', align: 'center', width: 32 },
              { header: 'System', key: 'system', width: 80 },
              { header: 'Description', key: 'desc' },
            ],
            rows: detail.faults.map((f) => ({
              id: f.fault_id, date: f.reported_at.slice(0, 10), status: f.status,
              type: f.fault_type, risk: f.risk_factor, system: f.system_name, desc: f.description,
            })),
          },
          {
            title: `Resource Requests (${detail.resources.length})`,
            columns: [
              { header: 'ID', key: 'id', width: 35 },
              { header: 'Requested', key: 'date', width: 62 },
              { header: 'Status', key: 'status', width: 70, isStatus: true },
              { header: 'Resource', key: 'name', width: 110 },
              { header: 'System', key: 'system', width: 80 },
              { header: 'Description', key: 'desc' },
            ],
            rows: detail.resources.map((r) => ({
              id: r.resource_id, date: r.requested_at.slice(0, 10), status: r.status,
              name: r.resource_name, system: r.system_name, desc: r.description,
            })),
          },
        ],
        fileName: `nexusgrid_detailed_report_${fileScope}.pdf`,
      });
      toast.success('Detailed PDF downloaded.');
    } catch {
      toast.error('Failed to download PDF report.');
    } finally {
      setExportingPdf(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <PageHeader
        title="Reports & Analytics"
        description={
          scopeLabel
            ? `Showing statistics for: ${scopeLabel}`
            : isRestricted
            ? 'Showing statistics for all your assigned labs.'
            : 'Visual overview of faults, resources, and system status.'
        }
        actions={
          <div className="flex items-center gap-2">
            <button onClick={downloadDetailedCsv} className="btn-secondary" disabled={exportingCsv || exportingPdf}>
              <Download className="w-4 h-4" /> {exportingCsv ? 'Exporting...' : 'CSV'}
            </button>
            <button onClick={downloadDetailedPdf} className="btn-primary" disabled={exportingCsv || exportingPdf}>
              <FileText className="w-4 h-4" /> {exportingPdf ? 'Generating...' : 'PDF Report'}
            </button>
            <button onClick={() => refetch()} className="btn-ghost" title="Refresh data">
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        }
      />

      {/* ── Filter bar ─────────────────────────────────────────────────────── */}
      {isAdmin && (
        <div className={`card p-4 flex flex-wrap items-end gap-4`}>
          <div className="flex items-center gap-2 mr-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Filter scope</span>
          </div>
          <FilterSelect
            label="Building" icon={Building2}
            value={selectedBuilding}
            onChange={v => { setSelectedBuilding(v); setSelectedFloor(''); setSelectedLab(''); }}
            placeholder="All buildings"
            options={buildings.map(b => ({ id: b.id, name: b.name }))}
            dark={dark}
          />
          <FilterSelect
            label="Floor" icon={Layers}
            value={selectedFloor}
            onChange={v => { setSelectedFloor(v); setSelectedLab(''); }}
            disabled={!selectedBuilding}
            placeholder={selectedBuilding ? 'All floors' : 'Select building first'}
            options={floors.map(f => ({ id: f.id, name: f.name }))}
            dark={dark}
          />
          <FilterSelect
            label="Lab" icon={BookOpen}
            value={selectedLab}
            onChange={setSelectedLab}
            disabled={!selectedFloor}
            placeholder={selectedFloor ? 'All labs' : 'Select floor first'}
            options={labsForFloor.map(l => ({ id: l.id, name: l.lab_name }))}
            dark={dark}
          />
          {isFiltered && (
            <button
              onClick={() => { setSelectedBuilding(''); setSelectedFloor(''); setSelectedLab(''); }}
              className={`flex items-center gap-1 text-xs px-3 py-2 rounded-lg border transition self-end
                ${dark ? 'border-slate-600 text-slate-400 hover:text-slate-200 hover:border-slate-400' : 'border-slate-200 text-slate-500 hover:text-slate-700 hover:border-slate-300'}`}
            >
              <X className="w-3 h-3" /> Clear
            </button>
          )}
        </div>
      )}

      {isRestricted && myLabs.length > 0 && (
        <div className={`card p-4 flex flex-wrap items-end gap-4`}>
          <div className="flex items-center gap-2 mr-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Filter scope</span>
          </div>
          <FilterSelect
            label="Lab" icon={BookOpen}
            value={selectedRestrictedLab}
            onChange={setSelectedRestrictedLab}
            placeholder="All my assigned labs"
            options={myLabs.map(a => ({ id: a.lab, name: a.lab_name }))}
            dark={dark}
          />
          {isFiltered && (
            <button
              onClick={() => setSelectedRestrictedLab('')}
              className={`flex items-center gap-1 text-xs px-3 py-2 rounded-lg border transition self-end
                ${dark ? 'border-slate-600 text-slate-400 hover:text-slate-200 hover:border-slate-400' : 'border-slate-200 text-slate-500 hover:text-slate-700 hover:border-slate-300'}`}
            >
              <X className="w-3 h-3" /> Clear
            </button>
          )}
        </div>
      )}

      {/* Scope info banner */}
      {isRestricted && (
        <div className={`flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm
          ${dark ? 'bg-blue-950/50 text-blue-300 border border-blue-800/50' : 'bg-blue-50 text-blue-700 border border-blue-100'}`}>
          <LayoutDashboard className="w-4 h-4 shrink-0" />
          <span>
            {selectedRestrictedLab
              ? `Filtered to: ${myLabs.find(l => l.lab === selectedRestrictedLab)?.lab_name ?? 'selected lab'}`
              : 'Statistics cover all labs you are currently assigned to.'}
          </span>
        </div>
      )}

      {/* ── Summary stat cards ─────────────────────────────────────────────── */}
      {!isLoading && data && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            label="Total Faults"
            value={totalFaults}
            icon={AlertTriangle}
            color="bg-red-50 dark:bg-red-950/40 text-red-500"
            subtext={`${resolvedFaults} resolved`}
          />
          <StatCard
            label="Open Faults"
            value={totalFaults - resolvedFaults}
            icon={TrendingUp}
            color="bg-amber-50 dark:bg-amber-950/40 text-amber-500"
          />
          <StatCard
            label="Resource Requests"
            value={totalResources}
            icon={Package}
            color="bg-blue-50 dark:bg-blue-950/40 text-blue-500"
          />
          <StatCard
            label="Total Systems"
            value={totalSystems}
            icon={Monitor}
            color="bg-violet-50 dark:bg-violet-950/40 text-violet-500"
          />
        </div>
      )}

      {/* ── Charts Row 1: Trends ───────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <ChartSection
          icon={TrendingUp}
          title="Monthly Fault Trend"
          subtitle="Breakdown by fault type"
        >
          {isLoading ? skeletonChart : (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={faultTrendData} barSize={16} barGap={2}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridStroke} vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: tickFill }} tickLine={false} axisLine={false} dy={6} />
                <YAxis tick={{ fontSize: 11, fill: tickFill }} tickLine={false} axisLine={false} dx={-4} allowDecimals={false} />
                <Tooltip {...tooltipProps} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={legendStyle} />
                {types.map((t, i) => (
                  <Bar key={t} dataKey={t} name={t} fill={COLORS[i % COLORS.length]} radius={[4, 4, 0, 0]} />
                ))}
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartSection>

        <ChartSection
          icon={Package}
          title="Resource Requests Trend"
          subtitle="Monthly request volume"
        >
          {isLoading ? skeletonChart : (
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={resourceTrend}>
                <defs>
                  <linearGradient id="resourceGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={gridStroke} vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: tickFill }} tickLine={false} axisLine={false} dy={6} />
                <YAxis tick={{ fontSize: 11, fill: tickFill }} tickLine={false} axisLine={false} dx={-4} allowDecimals={false} />
                <Tooltip {...tooltipProps} />
                <Area
                  type="monotone"
                  dataKey="count"
                  name="Requests"
                  stroke="#3b82f6"
                  strokeWidth={2.5}
                  fill="url(#resourceGradient)"
                  dot={{ r: 3, fill: '#3b82f6', strokeWidth: 0 }}
                  activeDot={{ r: 5, fill: '#3b82f6', stroke: '#fff', strokeWidth: 2 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </ChartSection>
      </div>

      {/* ── Charts Row 2: Distribution pies ────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <ChartSection icon={AlertTriangle} title="Faults by Status">
          {isLoading ? skeletonChart : (
            <ResponsiveContainer width="100%" height={190}>
              <PieChart>
                <Pie data={faultByStatusData} cx="50%" cy="50%" innerRadius={48} outerRadius={70}
                  paddingAngle={3} dataKey="value" strokeWidth={0}>
                  {faultByStatusData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                </Pie>
                <Tooltip {...tooltipProps} />
                <Legend iconType="circle" iconSize={7} wrapperStyle={legendStyle} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </ChartSection>

        <ChartSection icon={AlertTriangle} title="Faults by Type">
          {isLoading ? skeletonChart : (
            <ResponsiveContainer width="100%" height={190}>
              <PieChart>
                <Pie data={faultByTypeData} cx="50%" cy="50%" innerRadius={48} outerRadius={70}
                  paddingAngle={3} dataKey="value" strokeWidth={0}>
                  {faultByTypeData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                </Pie>
                <Tooltip {...tooltipProps} />
                <Legend iconType="circle" iconSize={7} wrapperStyle={legendStyle} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </ChartSection>

        <ChartSection icon={Package} title="Resources by Status">
          {isLoading ? skeletonChart : (
            <ResponsiveContainer width="100%" height={190}>
              <PieChart>
                <Pie data={resourceByStatusData} cx="50%" cy="50%" innerRadius={48} outerRadius={70}
                  paddingAngle={3} dataKey="value" strokeWidth={0}>
                  {resourceByStatusData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                </Pie>
                <Tooltip {...tooltipProps} />
                <Legend iconType="circle" iconSize={7} wrapperStyle={legendStyle} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </ChartSection>

        <ChartSection icon={Monitor} title="Systems by Status">
          {isLoading ? skeletonChart : (
            <ResponsiveContainer width="100%" height={190}>
              <PieChart>
                <Pie data={systemByStatusData} cx="50%" cy="50%" innerRadius={48} outerRadius={70}
                  paddingAngle={3} dataKey="value" strokeWidth={0}>
                  {systemByStatusData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                </Pie>
                <Tooltip {...tooltipProps} />
                <Legend iconType="circle" iconSize={7} wrapperStyle={legendStyle} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </ChartSection>
      </div>

      {/* ── Oversight section ──────────────────────────────────────────────── */}
      <div className="border-t border-slate-200 dark:border-slate-700 pt-6">
        <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-4">Oversight & Budgeting</h2>
        <OversightSection />
      </div>
    </div>
  );
}